//: Playground - noun: a place where people can play

import UIKit

class Dentaku{
    
    var xx: Double
    init(){
        xx = 0
    }
    

    func keisan(str1: String) -> Void{
        var dentaku1 = str1.components(separatedBy: ["+","-","*","/"])
        var dentaku2 = str1.components(separatedBy: ["0","1","2","3","4","5","6","7","8","9"])
            
        
        for str2 in dentaku2{
            
            
            if str2.contains("*") || str2.contains("/"){
                if let index1 = dentaku2.index(of: "*"), let index2 = dentaku2.index(of: "/"){

                    if index1 < index2 {
                        let number1 = Double(String(dentaku1[index1 - 1]))
                        let number2 = Double(String(dentaku1[index1]))
                        let number3 = number1! * number2!
                        let a = index1 - 1,b = index1
                        let number4 = String(number3)
                        let number5 = number4.components(separatedBy: "*")
                        dentaku1[a...b] = ArraySlice(number5)
                        dentaku2.remove(at: index1)
                    }else if index1 > index2{
                        let number1 = Double(String(dentaku1[index2 - 1]))
                        let number2 = Double(String(dentaku1[index2]))
                        let number3 = number1! / number2!
                        let a = index2 - 1,b = index2
                        let number4 = String(number3)
                        let number5 = number4.components(separatedBy: "/")
                        dentaku1[a...b] = ArraySlice(number5)
                        dentaku2.remove(at: index2)
                    }
                   
                    
                    
                }
            }
        }
               if dentaku2.contains("*") || dentaku2.contains("/"){
            if let index1 = dentaku2.index(of: "*"){
                let number1 = Double(String(dentaku1[index1 - 1]))
                let number2 = Double(String(dentaku1[index1]))
                let number3 = number1! * number2!
                let a = index1 - 1,b = index1
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "*")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index1)
            }else if let index2 = dentaku2.index(of: "/"){
                let number1 = Double(String(dentaku1[index2 - 1]))
                let number2 = Double(String(dentaku1[index2]))
                let number3 = number1! / number2!
                let a = index2 - 1,b = index2
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "/")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index2)    }
            
        }
        print(dentaku1)
        
        for str5 in dentaku2{
            if str5.contains("*"){
                if let index1 = dentaku2.index(of: "*"){
                    let number1 = Double(String(dentaku1[index1 - 1]))
                    let number2 = Double(String(dentaku1[index1]))
                    let number3 = number1! * number2!
                    let a = index1 - 1,b = index1
                    let number4 = String(number3)
                    let number5 = number4.components(separatedBy: "*")
                    dentaku1[a...b] = ArraySlice(number5)
                    dentaku2.remove(at: index1)
                }
            }else if let index1 = dentaku2.index(of: "/"){
                let number1 = Double(String(dentaku1[index1 - 1]))
                let number2 = Double(String(dentaku1[index1]))
                let number3 = number1! / number2!
                let a = index1 - 1,b = index1
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "/")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index1)        }}
        
        
        
        for str3 in dentaku2{
            
            
            if str3.contains("+") || str3.contains("-"){
                if let index1 = dentaku2.index(of: "+"), let index2 = dentaku2.index(of: "-"){
                   
                    if index1 < index2 {
                        let number1 = Double(String(dentaku1[index1 - 1]))
                        let number2 = Double(String(dentaku1[index1]))
                        let number3 = number1! + number2!
                        let a = index1 - 1,b = index1
                        let number4 = String(number3)
                        let number5 = number4.components(separatedBy: "+")
                        dentaku1[a...b] = ArraySlice(number5)
                        dentaku2.remove(at: index1)
                    }else if index1 > index2{
                        let number1 = Double(String(dentaku1[index2 - 1]))
                        let number2 = Double(String(dentaku1[index2]))
                        let number3 = number1! - number2!
                        let a = index2 - 1,b = index2
                        let number4 = String(number3)
                        let number5 = number4.components(separatedBy: "-")
                        dentaku1[a...b] = ArraySlice(number5)
                        dentaku2.remove(at: index2)
                    }
                    
                }
            }
        }
        print(dentaku1)
        print(dentaku2)
        
    
        if dentaku2.contains("+") || dentaku2.contains("-"){
            if let index1 = dentaku2.index(of: "+"){
                let number1 = Double(String(dentaku1[index1 - 1]))
                let number2 = Double(String(dentaku1[index1]))
                let number3 = number1! + number2!
                let a = index1 - 1,b = index1
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "+")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index1)
            }else if let index2 = dentaku2.index(of: "-"){
                let number1 = Double(String(dentaku1[index2 - 1]))
                let number2 = Double(String(dentaku1[index2]))
                let number3 = number1! - number2!
                let a = index2 - 1,b = index2
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "-")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index2)    }
            
        }
        
        print(dentaku1)
        print(dentaku2)
        for str4 in dentaku2{
            if str4.contains("+"){
                if let index1 = dentaku2.index(of: "+"){
                    let number1 = Double(String(dentaku1[index1 - 1]))
                    let number2 = Double(String(dentaku1[index1]))
                    let number3 = number1! + number2!
                    let a = index1 - 1,b = index1
                    let number4 = String(number3)
                    let number5 = number4.components(separatedBy: "+")
                    dentaku1[a...b] = ArraySlice(number5)
                    dentaku2.remove(at: index1)
                }
            }else if let index1 = dentaku2.index(of: "-"){
                let number1 = Double(String(dentaku1[index1 - 1]))
                let number2 = Double(String(dentaku1[index1]))
                let number3 = number1! - number2!
                let a = index1 - 1,b = index1
                let number4 = String(number3)
                let number5 = number4.components(separatedBy: "-")
                dentaku1[a...b] = ArraySlice(number5)
                dentaku2.remove(at: index1)        }
            
            print(dentaku1)
        }
        let dentaku4 = Double(String(dentaku1[0]))
        print(dentaku4!)
        
    }
    
}

var d = Dentaku()
d.keisan(str1: "1+3*5/4*3+7/4-8+9")


